import 'package:flutter/material.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:news_app/Screens/BottomNavPages/SavedPage.dart';
import 'package:news_app/Screens/BottomNavPages/TodayPage.dart';
import 'package:news_app/Screens/BottomNavPages/NotificationsPage.dart';
import 'package:news_app/main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:news_app/Components/Constants.dart';
class BottomNavScreen extends StatefulWidget {
  @override
  _BottomNavScreenState createState() => _BottomNavScreenState();
}

class _BottomNavScreenState extends State<BottomNavScreen> {

  int CurrentPage = 0;
  PageController _controller = new PageController(initialPage: 0);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onbackPressed, //prevents going to login screen
      child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            elevation: 8,
            centerTitle: true,
            title: Text('ABC NEWS',style: GoogleFonts.montserrat(color: Constants.primary_dark,fontWeight: FontWeight.bold),),
            leading: InkWell(
              splashColor: Constants.primary_light,
              onTap: (){
                Scaffold.of(context).openDrawer();
              },
              customBorder: CircleBorder(),
              child: Builder(
                  builder: (context)=>IconButton(
                    icon: Icon(Icons.menu_sharp,color: Constants.highlight_medium,),
                    onPressed: ()=>Scaffold.of(context).openDrawer(),
                  ),
                  ),
            ),
            actions: [
              InkWell(
                onTap: (){},
                splashColor: Constants.primary_light,
                customBorder: CircleBorder(),
                child: Container(
                  margin: EdgeInsets.only(right: 10),
                  child: Padding(
                      padding: EdgeInsets.all(5),
                      child: Icon(Icons.search_outlined,color: Constants.highlight_medium,),
                  ),
                ),
              ),
            ],
          ),
        drawer: new Drawer(),
        bottomNavigationBar: BottomNavigationBar(
            onTap: (index){
              setState(() {
                CurrentPage = index;
                _controller.jumpToPage(index);
              });
            },
            showUnselectedLabels: true,
            selectedItemColor: Constants.primary_dark,
            unselectedItemColor: Constants.primary_light,
            selectedLabelStyle: GoogleFonts.roboto(fontSize: 14),
            unselectedLabelStyle: GoogleFonts.roboto(fontSize: 12),
            currentIndex: CurrentPage,
            type: BottomNavigationBarType.fixed,//change this if needed
            items: [
              BottomNavigationBarItem(
                icon: CurrentPage == 0 ?Icon(EvaIcons.fileText) :Icon(EvaIcons.fileTextOutline),
                label: 'Latest',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.add_to_photos),
                label: 'Today',
              ),
              BottomNavigationBarItem(
                icon: CurrentPage == 2 ? Icon(EvaIcons.bookmark) : Icon(EvaIcons.bookmarkOutline),
                label: 'Saved',
              ),
              BottomNavigationBarItem(
                icon: CurrentPage == 3 ? Icon(Icons.notifications) : Icon(Icons.notifications_none_outlined),
                label: 'Notifications',
              ),
            ]),
        body: PageView(
          physics: NeverScrollableScrollPhysics(),
          scrollDirection: Axis.horizontal,
          pageSnapping: true,
          onPageChanged: (index){
            setState(() {
              CurrentPage = index;
            });
          },
          controller: _controller,
          children: [
            MyApp(),
            TodayPage(),
            SavedPage(),
            NotficationPage(),
          ],
        ),
      ),
    );
  }

  Future<bool> _onbackPressed() async{
    return true;
  }
}
