import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:io';
import 'package:news_app/Components/Constants.dart';
import 'package:news_app/Screens/BottomNavScreen.dart';
import 'package:news_app/Screens/LoginScreen.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:news_app/cache.dart';
import 'package:path_provider/path_provider.dart';
import 'package:news_app/home.dart';
import 'package:dio/dio.dart';
import 'user.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(MaterialApp(
    title: 'Rest Api',
    debugShowCheckedModeBanner: false,
    initialRoute: '/',
    routes: {
      '/': (context) => LoginScreen(),
    },
  ));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with TickerProviderStateMixin {
  late var futureAlbum;
  var check;
  var loading;
  late AnimationController controller;
  fetchdata(int num) async {
    setState(() {
      loading = false;
    });
    String filename = 'CacheData.json';
    var cacheDir = await getTemporaryDirectory();
    print(cacheDir);
    if (await File(cacheDir.path + "/" + filename).exists()) {
      print("Loading from cache");
      var jsonData = File(cacheDir.path + "/" + filename).readAsStringSync();
      final response = jsonDecode(jsonData);
      return response;
    } else {
      print("Loading from API");
      final response = await Dio().get(
          'https://wcreu.com/index.php/wp-json/wp/v2/posts?per_page=20&categories=$num&status=publish');

      if (response.statusCode == 200) {
        setState(() async {
          futureAlbum = response.data;
          loading = true;
          var tempDir = await getTemporaryDirectory();
          print(tempDir);
          File file = new File(tempDir.path + "/" + filename);
          file.writeAsString(futureAlbum, flush: true, mode: FileMode.write);
          return jsonDecode(response.data);
        });
      } else {
        throw Exception('Failed to load album');
      }
    }
  }

  final Shader _linearGradient = LinearGradient(
    colors: <Color>[Constants.highlight_medium,Constants.primary_light],
  ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  void initState() {
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..addListener(() {
        setState(() {});
      });
    controller.repeat(reverse: true);
    super.initState();

    futureAlbum = fetchdata(6);
  }
  @override
  Widget build(BuildContext context) {
    int CurrentIndex=0;
    if (loading == true) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        CategoryBox(6,'सभी समाचार'),
                        CategoryBox(5,'अंतरराष्ट्रीय'),
                        CategoryBox(25,'स्थानीय समाचार'),
                        CategoryBox(25,'राजस्थान'),
                        CategoryBox(25,'ई पेपर'),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 10,),
                Expanded(
                  child: Container(
                    //height: MediaQuery.of(context).size.height - 180,
                    child: ListView.builder(
                      itemCount: loading ? futureAlbum.length : 0,
                      itemBuilder: (context, index) {
                        return Container(
                          margin: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                          width: MediaQuery.of(context).size.width,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(futureAlbum[index]['title']['rendered'].toString(),overflow: TextOverflow.clip,
                                  style: GoogleFonts.montserrat(fontSize: 24,fontWeight: FontWeight.bold,foreground: Paint()..shader = _linearGradient),
                                ),
                              ),
                              GestureDetector(
                                onTap: (){
                                  Navigator.push(
                                      context,
                                      CupertinoPageRoute(builder: (context) => Datapage(futureAlbum[index])));
                                },
                                child: Container(
                                  width: double.infinity,
                                  height: MediaQuery.of(context).size.height*0.3,
                                  decoration: BoxDecoration(
                                      color: Constants.primary_light,
                                      image: DecorationImage(image: NetworkImage(futureAlbum[index]['jetpack_featured_media_url']),fit: BoxFit.fill)
                                  ),
                                ),
                              ),//image
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  //date
                                  Text(futureAlbum[index]['date'],style: TextStyle(color:Colors.black,fontSize: 14,fontWeight: FontWeight.w400),),
                                  Container(
                                    child: Row(
                                      children: [
                                        GestureDetector(
                                          onTap: (){
                                            //save feature here

                                          },
                                          child: Container(
                                              child: Icon(Icons.bookmark_outline,color: Constants.highlight_medium,)
                                          ),
                                        ),
                                        SizedBox(width: 5,),
                                        GestureDetector(
                                          onTap: (){
                                            //share feature here
                                          },
                                          child: Container(
                                            child:Icon(Icons.share,color: Constants.highlight_medium),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              Text('This is the sample description of a news item',overflow: TextOverflow.clip,
                                style: TextStyle(fontSize: 16,color: Constants.highlight_medium,fontWeight: FontWeight.w500),),
                            ],
                          ),
                        );

                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          drawer: Drawer(),
        ),
      );
    } else {
      return Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Text('Please Wait while we fetch your data',overflow: TextOverflow.clip,
                style: TextStyle(color: Constants.highlight_medium,fontWeight: FontWeight.w500,fontSize: 14),),
            ),
            SizedBox(height: 10,),
            Center(
              child: CircularProgressIndicator(
                  value: controller.value,
                  backgroundColor: Constants.accent,
                  valueColor: AlwaysStoppedAnimation<Color>(Constants.highlight_medium),
                  semanticsLabel: 'Linear progress indicator',
                ),
            ),
          ],
        ),
      );
    }
  }

  Widget CategoryBox(int index,String text){
    return GestureDetector(
      onTap: (){
        fetchdata(index);
      },
      child: Container(
        margin: EdgeInsets.only(right: 10),
        decoration: BoxDecoration(color: Colors.white,
            border: Border(bottom: BorderSide(
          color: Constants.primary_light,
          width: 2,
        ))),
        child: Text('$text',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 22,foreground: Paint()..shader = _linearGradient),),
      ),
    );
  }

}


class Datapage extends StatefulWidget {

  var futurealbum;
  Datapage(@required this.futurealbum);

  @override
  _DatapageState createState() => _DatapageState();
}

class _DatapageState extends State<Datapage> {
  double des_font = 16;

  final Shader _linearGradient = LinearGradient(
    colors: <Color>[Constants.primary_dark,Constants.highlight_medium],
  ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  Future<bool> _onbackPressed()async{
    Navigator.pop(context);
    return true;
  }

  bool alreadySaved = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WillPopScope(
        onWillPop: _onbackPressed,
        child: Align(
          alignment: Alignment.topCenter,
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            physics: ScrollPhysics(),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20,vertical: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: (){
                                  //save feature here
                                    if(alreadySaved==true)
                                    {
                                      setState(() {
                                        alreadySaved = false;
                                        //remove from saved
                                      });
                                      }
                                      else
                                        {
                                          setState(() {
                                            alreadySaved = true;
                                            //add to save
                                          });
                                        }
                                },
                                child: Container(
                                  child: alreadySaved == true ? Icon(Icons.bookmark,color: Constants.highlight_medium,)
                                      : Icon(Icons.bookmark_outline,color: Constants.highlight_medium,),
                                ),
                              ),
                              SizedBox(width: 5,),
                              GestureDetector(
                                onTap: (){
                                  //share feature here
                                },
                                child: Container(
                                  child:Icon(Icons.share,color: Constants.highlight_medium),
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            if(des_font >= 40)
                              {
                                setState(() {
                                  des_font = 16;
                                });
                              }
                            else{
                              setState(() {
                                des_font+=4;
                              });
                            }
                          },
                          child: Container(
                              padding: EdgeInsets.all(5),
                              color: Colors.white,
                              child: Icon(Icons.font_download,color: Constants.highlight_medium,)),
                        ),
                      ],
                    ),
                  Align(
                      alignment: Alignment.topLeft,
                      child: Text('News Heading',style: GoogleFonts.montserrat(fontSize: 34,fontWeight: FontWeight.bold,
                          foreground: Paint()..shader = _linearGradient)
                        ,overflow: TextOverflow.clip,)),
                  Container(
                    height: MediaQuery.of(context).size.height*0.3,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      image: DecorationImage(image: NetworkImage(widget.futurealbum['jetpack_featured_media_url']),fit: BoxFit.fill)
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(widget.futurealbum['date'].toString(),style: TextStyle(fontWeight: FontWeight.w400,fontSize: 14),),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Text(widget.futurealbum['id'].toString(),style: TextStyle(fontWeight: FontWeight.w400,fontSize: 14),),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text('This is some sample description related to the news',
                      style: TextStyle(fontSize: des_font,fontWeight: FontWeight.normal,color: Colors.black),
                      overflow: TextOverflow.clip,),
                  ),
                  //unused old data
                  /*
                  Text(
                    widget.futurealbum['id'].toString(),
                    style: TextStyle(
                      fontSize: 25,
                    ),
                  ),
                  Image.network(
                    widget.futurealbum['jetpack_featured_media_url'],
                    height: 350,
                    width: 200,
                  ),
                  Text(
                    widget.futurealbum['date'].toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.futurealbum['status'].toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.futurealbum['title']['rendered'].toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.futurealbum.length.toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                   */
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
//removed codes
//old pdf card
/*
                        Container(
                          height: 200,
                          child: Padding(
                            padding: EdgeInsets.all(10),
                            child: ListTile(
                              title: Image.network(futureAlbum[index]
                                  ['jetpack_featured_media_url']),
                              subtitle: Text(futureAlbum[index]['date']),
                              trailing: FlatButton(
                                child: Text('-->'),
                                color: Colors.blueAccent,
                                textColor: Colors.white,
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              Datapage(futureAlbum[index])));
                                },
                              ),
                            ),
                          ),
                        );
                         */