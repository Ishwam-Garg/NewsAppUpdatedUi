import 'package:flutter/material.dart';
import 'package:flutter_app/Components/Theme.dart';

class AboutPage extends StatelessWidget {

  String sample_about = 'स्मार्ट हलचल App is designed to update you with the latest news form around all of Rajasthan';


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeNotifier().darkTheme ? light : dark,
      home: Scaffold(
        appBar: AppBar(
          leading: GestureDetector(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back),
          ),
          centerTitle: true,
          title: Text('About',style: TextStyle(fontWeight: FontWeight.bold),),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                Center(
                  child: Text(sample_about,style: TextStyle(fontWeight: FontWeight.w500,fontSize: 14),overflow: TextOverflow.clip,),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
