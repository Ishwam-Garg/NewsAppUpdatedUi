import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_app/Components/Theme.dart';
import 'package:flutter_app/Screens/BottomNavPages/SavedPage.dart';
import 'package:flutter_app/Screens/BottomNavPages/TodayPage.dart';
import 'package:flutter_app/Screens/BottomNavPages/NotificationsPage.dart';
import 'package:flutter_app/main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_app/Components/Constants.dart';
import 'package:provider/provider.dart';

import '../BookmarkPage.dart';

class BottomNavScreen extends StatefulWidget {
  @override
  _BottomNavScreenState createState() => _BottomNavScreenState();
}

class _BottomNavScreenState extends State<BottomNavScreen> {
  int CurrentPage = 0;
  PageController _controller = new PageController(initialPage: 0);
  late String userimage = '';

  ImageProvider userImageProvider(String image) {
    if (image == '') {
      return AssetImage('Assets/Images/profile.png');
    } else {
      return NetworkImage(image);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: Consumer<ThemeNotifier>(
        builder: (context, ThemeNotifier notifier, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: notifier.darkTheme ? dark : light,
            home: WillPopScope(
              onWillPop: _onbackPressed, //prevents going to login screen
              child: Scaffold(
                appBar: AppBar(
                  //backgroundColor: Colors.white,
                  elevation: 0,
                  centerTitle: true,
                  title: Text(
                    'Smart HalChal',
                  ),
                  leading: InkWell(
                    splashColor: Constants.primary_light,
                    onTap: () {
                      Scaffold.of(context).openDrawer();
                    },
                    customBorder: CircleBorder(),
                    child: Builder(
                      builder: (context) => IconButton(
                        icon: Icon(Icons.menu_sharp),
                        onPressed: () => Scaffold.of(context).openDrawer(),
                      ),
                    ),
                  ),
                  actions: [
                    InkWell(
                      onTap: () {},
                      splashColor: Constants.primary_light,
                      customBorder: CircleBorder(),
                      child: Container(
                        margin: EdgeInsets.only(right: 10),
                        child: Padding(
                          padding: EdgeInsets.all(5),
                          child: Icon(Icons.search_outlined),
                        ),
                      ),
                    ),
                  ],
                ),
                drawer: new Drawer(
                    child: Container(
                      margin: EdgeInsets.only(
                        left: 20,
                        top: MediaQuery.of(context).size.height * 0.1,
                      ),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.only(topLeft: Radius.circular(20)),
                      ),
                      child: SingleChildScrollView(
                        physics: ScrollPhysics(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            //account container
                            Container(
                              padding: EdgeInsets.only(left: 10, top: 10),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20)
                                ),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: 10, top: 10),
                                    child: CircleAvatar(
                                      radius: 30,
                                      backgroundColor: Constants.primary_dark,
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(left: 10, top: 10),
                                    width:
                                        MediaQuery.of(context).size.width * 0.3,
                                    child: Text(
                                      'Ishwam',
                                      overflow: TextOverflow.clip,
                                      maxLines: 2,
                                      style: GoogleFonts.montserrat(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () {},
                                    child: Container(
                                      padding:
                                          EdgeInsets.only(left: 10, top: 10),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.edit_outlined,
                                            size: 18,
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          Text(
                                            'Edit Profile',
                                            style: GoogleFonts.montserrat(),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Consumer<ThemeNotifier>(
                                    builder: (context, notifier, child) =>
                                        SwitchListTile(
                                          value: notifier.darkTheme,
                                           onChanged: (val) {
                                           notifier.toggleTheme();
                                              },
                                          title: Text(
                                        notifier.darkTheme
                                            ? 'Dark Mode'
                                            : 'Light Mode',
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            //saved
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                padding: EdgeInsets.only(
                                    left: 20, top: 10, bottom: 10),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                        width: 0.5,
                                    ),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.bookmark_rounded,
                                      size: 24,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    BookmarkPage()));
                                      },
                                      child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.4,
                                          child: AutoSizeText(
                                            'Saved',
                                            style: GoogleFonts.montserrat(
                                                fontSize: 18),
                                          )),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            //about
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                padding: EdgeInsets.only(
                                    left: 20, top: 10, bottom: 10),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                        width: 0.5,
                                    ),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Icon(
                                      EvaIcons.info,
                                      size: 24,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.4,
                                        child: AutoSizeText(
                                          'About',
                                          style: GoogleFonts.montserrat(
                                              fontSize: 18),
                                        )),
                                  ],
                                ),
                              ),
                            ),
                            //Help
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                padding: EdgeInsets.only(
                                    left: 20, top: 10, bottom: 10),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                        width: 0.5,
                                        ),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.help,
                                      size: 24,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Help',
                                      style: GoogleFonts.montserrat(
                                          fontSize: 18),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            //settings box not required currently
                            /*
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                padding: EdgeInsets.only(
                                    left: 20, top: 10, bottom: 10),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border(
                                    bottom: BorderSide(
                                        width: 0.5,
                                        color: Constants.primary_light),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.settings,
                                      color: Constants.highlight_medium,
                                      size: 28,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Settings',
                                      style: GoogleFonts.montserrat(
                                          color: Constants.highlight_medium,
                                          fontSize: 18),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                             */
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                padding: EdgeInsets.only(
                                    left: 20, top: 10, bottom: 10),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                        width: 0.5,
                                    ),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Icon(
                                      EvaIcons.alertTriangle,
                                      size: 24,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Disclaimer',
                                      style: GoogleFonts.montserrat(
                                          fontSize: 18),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 20, right: 20),
                              child: Material(
                                borderRadius: BorderRadius.circular(10),
                                elevation: 5,
                                child: Container(
                                  margin: EdgeInsets.symmetric(horizontal: 10),
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  width: double.infinity,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Log Out',
                                        style: GoogleFonts.montserrat(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Icon(
                                        Icons.logout,
                                        size: 18,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                bottomNavigationBar: BottomNavigationBar(
                    onTap: (index) {
                      setState(() {
                        CurrentPage = index;
                        _controller.jumpToPage(index);
                      });
                    },
                    showUnselectedLabels: true,
                    //selectedItemColor: Constants.primary_dark,
                    //unselectedItemColor: Constants.primary_light,
                    selectedLabelStyle: GoogleFonts.roboto(
                        fontSize: 14, fontWeight: FontWeight.w600),
                    unselectedLabelStyle: GoogleFonts.roboto(
                        fontSize: 12, fontWeight: FontWeight.w500),
                    currentIndex: CurrentPage,
                    type: BottomNavigationBarType.fixed, //change this if needed
                    items: [
                      BottomNavigationBarItem(
                        icon: CurrentPage == 0
                            ? Icon(EvaIcons.fileText)
                            : Icon(EvaIcons.fileTextOutline),
                        label: 'Latest',
                      ),
                      BottomNavigationBarItem(
                        icon: CurrentPage == 1
                            ? Icon(Icons.add_to_photos)
                            : Icon(Icons.add_to_photos_outlined),
                        label: 'Today',
                      ),
                      BottomNavigationBarItem(
                        icon: CurrentPage == 2
                            ? Icon(EvaIcons.bookmark)
                            : Icon(EvaIcons.bookmarkOutline),
                        label: 'Saved',
                      ),
                      BottomNavigationBarItem(
                        icon: CurrentPage == 3
                            ? Icon(Icons.notifications)
                            : Icon(Icons.notifications_none_outlined),
                        label: 'Notifications',
                      ),
                    ]),
                body: PageView(
                  physics: ScrollPhysics(),
                  scrollDirection: Axis.horizontal,
                  pageSnapping: true,
                  onPageChanged: (index) {
                    setState(() {
                      CurrentPage = index;
                    });
                  },
                  controller: _controller,
                  children: [
                    MyApp(),
                    TodayPage(),
                    SavedPage(),
                    NotficationPage(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<bool> _onbackPressed() async {
    return true;
  }
}
