import 'package:flutter/material.dart';
import 'package:flutter_app/Components/Theme.dart';

class DisclaimerPage extends StatelessWidget {

  String disclaimer = "Disclaimer This mobile app is intended for informational, educational and research purposes only. It is not, and is not intended for use inthe diagnosis of disease or other conditions, or in the cure, mitigation, treatment, or prevention of disease, in man or otheranimals."
      " Health care providers should exercise their own independent clinical judgment when using the mobile app inconjunction with patient care.";

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeNotifier().darkTheme ? light : dark,
      home: Scaffold(
        appBar: AppBar(
          leading: GestureDetector(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back),
          ),
          centerTitle: true,
          title: Text('Disclaimer',style: TextStyle(fontWeight: FontWeight.bold),),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                Center(
                  child: Text(disclaimer,style: TextStyle(fontWeight: FontWeight.w500,fontSize: 14),overflow: TextOverflow.clip,),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
