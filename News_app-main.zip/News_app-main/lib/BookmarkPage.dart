import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'DatabaseManager.dart';

class BookmarkPage extends StatefulWidget {
  @override
  _BookmarkPageState createState() => _BookmarkPageState();
}

class _BookmarkPageState extends State<BookmarkPage>
    with TickerProviderStateMixin {
  var db;
  late bool loading;
  late AnimationController controller;
  getbookmarks() async {
    db = await DbManager().main2();
    setState(() {
      loading = false;
    });
  }

  @override
  void initState() {
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..addListener(() {
        setState(() {});
      });
    super.initState();
    loading = true;
    getbookmarks();
  }

  @override
  Widget build(BuildContext context) {
    if (loading == false) {
      return Scaffold(
        body: FutureBuilder<List>(
          future: DbManager().bookmarks(db),
          builder: (context, snapshot) {
            return snapshot.hasData
                ? ListView.builder(
                    itemCount: snapshot.data!.length,
                    itemBuilder: (_, int position) {
                      final item = snapshot.data![position];
                      //get your item data here ...
                      return Container(
                        margin: EdgeInsets.symmetric(horizontal: 10),
                        child: Material(
                          borderRadius: BorderRadius.circular(15),
                          elevation: 5,
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            margin: EdgeInsets.only(top: 20),
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 20.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: double.infinity,
                                    height: MediaQuery.of(context).size.height*0.4,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(image: NetworkImage(item.row[1]),fit: BoxFit.fill),
                                    ),
                                  ),
                                  Text(item.row[2].toString(),style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),maxLines: 2,),
                                  Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(item.row[4].toString().split('T')[0],maxLines: 5,)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                      /*
                      Card(
                        child: ListTile(
                          title: CachedNetworkImage(
                            imageUrl: item.row[1],
                          ),
                          subtitle: Text(item.row[2].toString()),
                          trailing: Text(item.row[4].toString()),
                        ),
                      );
                       */
                    },
                  )
                : Center(
                    child: CircularProgressIndicator(),
                  );
          },
        ),
      );
    } else {
      return Scaffold(
        body: Center(
          child: Column(
            children: [
              Text('Your data is loading...',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w500),overflow: TextOverflow.clip,),
              CircularProgressIndicator(
                value: controller.value,
                semanticsLabel: 'Linear progress indicator',
              ),
            ],
          ),
        ),
      );
    }
  }
}
