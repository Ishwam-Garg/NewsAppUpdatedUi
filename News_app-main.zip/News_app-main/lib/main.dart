import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_app/Components/Constants.dart';
import 'package:flutter_app/Screens/BottomNavScreen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:share/share.dart';
import 'DatabaseManager.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:html/parser.dart' show parse;
import 'package:html2md/html2md.dart' as html2md;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(MaterialApp(
    title: 'Rest Api',
    debugShowCheckedModeBanner: false,
    initialRoute: '/',
    routes: {
      '/': (context) => BottomNavScreen(),
    },
  ));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with TickerProviderStateMixin {
  late var futureAlbum;
  var check;
  var loading;
  var db;
  var id;
  var data;
  var html;
  var alldata;
  late List bookmarkid = [];
  late AnimationController controller;
  fetchdata(int num) async {
    setState(() {
      loading = false;
    });
    if (num == 0) {
      final response =
          await Dio().get('https://smarthalchal.com/wp-json/wp/v2/posts');
      if (response.statusCode == 200) {
        setState(() async {
          futureAlbum = response.data;
          loading = true;

          return jsonDecode(response.data);
        });
      } else {
        throw Exception('Failed to load album');
      }
    } else {
      final response = await Dio()
          .get('https://smarthalchal.com/wp-json/wp/v2/posts?categories=$num');
      if (response.statusCode == 200) {
        setState(() async {
          futureAlbum = response.data;
          loading = true;

          return jsonDecode(response.data);
        });
      } else {
        throw Exception('Failed to load album');
      }
    }
  }

  fetchids() async {
    db = await DbManager().main2();
    id = await DbManager().bookmarksids(db);
    for (int i = 0; i < id.length; i++) {
      bookmarkid.add(id[i]['id']);
    }
  }

  final Shader _linearGradient = LinearGradient(
    colors: <Color>[Constants.highlight_medium, Constants.primary_light],
  ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  void initState() {
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..addListener(() {
        setState(() {});
      });
    controller.repeat(reverse: true);
    super.initState();

    futureAlbum = fetchdata(290);
    fetchids();
  }

  @override
  Widget build(BuildContext context) {
    if (loading == true) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        CategoryBox(0, 'सभी समाचार'),
                        CategoryBox(37155, 'भीलवाड़ा'),
                        CategoryBox(37157, 'जयपुर-अजमेर'),
                        CategoryBox(290, 'कोटा-बारां'),
                        CategoryBox(36778, 'चित्तौड़गढ़-उदैपुर'),
                        CategoryBox(287, 'भारत'),
                        CategoryBox(293, 'राज्य'),
                        CategoryBox(32156, 'टोंक-चाकसू'),
                        CategoryBox(289, 'प्रौद्योगिकी'),
                        CategoryBox(288, 'राजस्थान-समाचार'),
                        CategoryBox(292, 'वीडियो'),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: Container(
                    //height: MediaQuery.of(context).size.height - 180,
                    child: ListView.builder(
                      itemCount: loading ? futureAlbum.length : 0,
                      itemBuilder: (context, index) {
                        if (index == 0) {
                          return Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),
                            width: MediaQuery.of(context).size.width,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        CupertinoPageRoute(
                                            builder: (context) => Datapage(
                                                futureAlbum[index],
                                                bookmarkid)));
                                  },
                                  child: Container(
                                    width: double.infinity,
                                    height: MediaQuery.of(context).size.height *
                                        0.3,
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: NetworkImage(futureAlbum[
                                                    index]
                                                ['jetpack_featured_media_url']),
                                            fit: BoxFit.fill)),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    futureAlbum[index]['title']['rendered']
                                        .toString(),
                                    overflow: TextOverflow.clip,
                                    maxLines: 2,
                                    style: GoogleFonts.montserrat(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ), //image
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    html2md
                                        .convert(futureAlbum[index]['content']
                                            ['rendered'])
                                        .toString()
                                        .toString(),
                                    overflow: TextOverflow.clip,
                                    maxLines: 3,
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    //date
                                    Text(
                                      futureAlbum[index]['date'],
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w400),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        } else {
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                      builder: (context) => Datapage(
                                          futureAlbum[index], bookmarkid)));
                            },
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: MediaQuery.of(context).size.width * 0.2,
                              margin: EdgeInsets.only(bottom: 20, top: 10),
                              padding: EdgeInsets.symmetric(horizontal: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width * 0.4,
                                    //height:
                                        //MediaQuery.of(context).size.width * 0.2,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: NetworkImage(futureAlbum[index]
                                              ['jetpack_featured_media_url']),
                                          fit: BoxFit.fill),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.6,
                                      //height: MediaQuery.of(context).size.width * 0.2,
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 10),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Flexible(
                                            child: Text(
                                              futureAlbum[index]['title']
                                                      ['rendered']
                                                  .toString(),
                                              overflow: TextOverflow.clip,
                                              maxLines: 1,
                                              style: GoogleFonts.montserrat(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          Flexible(
                                            child: Text(
                                              html2md
                                                  .convert(futureAlbum[index]
                                                      ['content']['rendered'])
                                                  .toString() + '....',
                                              overflow: TextOverflow.clip,
                                              //maxLines: 2,
                                              style: GoogleFonts.ubuntu(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } else {
      return Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Text(
                'Please Wait while we fetch your data',
                overflow: TextOverflow.clip,
                style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 14),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Center(
              child: CircularProgressIndicator(
                value: controller.value,
                semanticsLabel: 'Linear progress indicator',
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget CategoryBox(int index, String text) {
    return GestureDetector(
      onTap: () {
        fetchdata(index);
      },
      child: Container(
        margin: EdgeInsets.only(right: 10),
        child: Align(
            alignment: Alignment.topCenter,
            child: Text(
              '$text',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
              ),
            )),
      ),
    );
  }
}

class Datapage extends StatefulWidget {
  var futurealbum;
  late List bookmarkid;
  Datapage(@required this.futurealbum, this.bookmarkid);

  @override
  _DatapageState createState() => _DatapageState();
}

class _DatapageState extends State<Datapage> {
  double des_font = 16;
  var database;

  Future<bool> _onbackPressed() async {
    Navigator.pop(context);
    return true;
  }

  bool alreadySaved = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WillPopScope(
        onWillPop: _onbackPressed,
        child: Align(
          alignment: Alignment.topCenter,
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            physics: ScrollPhysics(),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        child: Row(
                          children: [
                            widget.bookmarkid.contains(widget.futurealbum['id'])
                                ? GestureDetector(
                                    onTap: () async {
                                      print('item exists delete item');
                                      widget.bookmarkid
                                          .remove(widget.futurealbum['id']);
                                      database = await DbManager().main2();
                                      await DbManager().deleteBM(
                                          database, widget.futurealbum['id']);
                                      Fluttertoast.showToast(
                                        msg: "Removed From Bookmarks",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.CENTER,
                                      );
                                    },
                                    child: Container(
                                        child: Icon(
                                      Icons.bookmark,
                                    )),
                                  )
                                : GestureDetector(
                                    onTap: () async {
                                      widget.bookmarkid
                                          .add(widget.futurealbum['id']);
                                      database = await DbManager().main2();
                                      await DbManager().insertbookmark(
                                          database,
                                          Bookmark(
                                            id: widget.futurealbum['id'],
                                            image: widget.futurealbum[
                                                'jetpack_featured_media_url'],
                                            title: widget.futurealbum['title']
                                                ['rendered'],
                                            desc: widget.futurealbum['content']
                                                ['rendered'],
                                            date: widget.futurealbum['date']
                                                .toString(),
                                          ));
                                      Fluttertoast.showToast(
                                        msg: "Added to Bookmarks",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.CENTER,
                                      );
                                    },
                                    child: Container(
                                      child: Icon(
                                        Icons.bookmark_outline,
                                      ),
                                    ),
                                  ),
                            SizedBox(
                              width: 5,
                            ),
                            GestureDetector(
                              onTap: () {
                                Share.share(
                                    widget.futurealbum['link'].toString());
                              },
                              child: Container(
                                child: Icon(Icons.share,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      //Text('font size: '+des_font.toString(),style: TextStyle(fontWeight: FontWeight.w500),),
                      GestureDetector(
                        onTap: () {
                          if (des_font >= 40) {
                            setState(() {
                              des_font = 16;
                            });
                          } else {
                            setState(() {
                              des_font += 4;
                            });
                          }
                        },
                        child: Container(
                            padding: EdgeInsets.all(5),
                            color: Colors.transparent,
                            child: Icon(
                              Icons.font_download,
                            )),
                      ),
                    ],
                  ),
                  Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        widget.futurealbum['title']['rendered'],
                        style: GoogleFonts.montserrat(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            ),
                        overflow: TextOverflow.clip,
                      )),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.3,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        color: Colors.red,
                        image: DecorationImage(
                            image: NetworkImage(widget
                                .futurealbum['jetpack_featured_media_url']),
                            fit: BoxFit.fill)),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          widget.futurealbum['date'].toString(),
                          style: TextStyle(
                              fontWeight: FontWeight.w400, fontSize: 14),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Text(
                          widget.futurealbum['id'].toString(),
                          style: TextStyle(
                              fontWeight: FontWeight.w400, fontSize: 14),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      html2md.convert(widget.futurealbum['content']['rendered']
                          .replaceAll(
                              new RegExp(
                                  r'[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ<>/"=?():;_%-]'),
                              '')),
                      style: TextStyle(
                          fontSize: des_font,
                          fontWeight: FontWeight.normal,
                          color: Colors.black),
                      overflow: TextOverflow.clip,
                    ),
                  ),
                  //unused old data
                  /*
                  Text(
                    widget.futurealbum['id'].toString(),
                    style: TextStyle(
                      fontSize: 25,
                    ),
                  ),
                  Image.network(
                    widget.futurealbum['jetpack_featured_media_url'],
                    height: 350,
                    width: 200,
                  ),
                  Text(
                    widget.futurealbum['date'].toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.futurealbum['status'].toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.futurealbum['title']['rendered'].toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.futurealbum.length.toString(),
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                   */
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
//removed codes
//old pdf card
/*
                        Container(
                          height: 200,
                          child: Padding(
                            padding: EdgeInsets.all(10),
                            child: ListTile(
                              title: Image.network(futureAlbum[index]
                                  ['jetpack_featured_media_url']),
                              subtitle: Text(futureAlbum[index]['date']),
                              trailing: FlatButton(
                                child: Text('-->'),
                                color: Colors.blueAccent,
                                textColor: Colors.white,
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              Datapage(futureAlbum[index])));
                                },
                              ),
                            ),
                          ),
                        );
                         */
//color: Constants.highlight_medium,
